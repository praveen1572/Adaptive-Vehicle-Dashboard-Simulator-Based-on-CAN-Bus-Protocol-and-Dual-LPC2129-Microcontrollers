.\can1_intrpt.o: can1_intrpt.c
.\can1_intrpt.o: header.h
.\can1_intrpt.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\can1_intrpt.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
