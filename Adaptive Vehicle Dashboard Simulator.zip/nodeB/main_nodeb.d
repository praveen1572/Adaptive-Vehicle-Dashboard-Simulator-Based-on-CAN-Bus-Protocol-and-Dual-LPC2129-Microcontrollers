.\main_nodeb.o: main_nodeB.c
.\main_nodeb.o: header.h
.\main_nodeb.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\main_nodeb.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
