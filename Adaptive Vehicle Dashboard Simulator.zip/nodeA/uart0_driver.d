.\uart0_driver.o: uart0_driver.c
.\uart0_driver.o: header.h
.\uart0_driver.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\uart0_driver.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
