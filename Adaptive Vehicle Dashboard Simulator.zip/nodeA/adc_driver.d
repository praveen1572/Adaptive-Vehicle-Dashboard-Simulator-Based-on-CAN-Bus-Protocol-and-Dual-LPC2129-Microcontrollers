.\adc_driver.o: adc_driver.c
.\adc_driver.o: header.h
.\adc_driver.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\adc_driver.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
