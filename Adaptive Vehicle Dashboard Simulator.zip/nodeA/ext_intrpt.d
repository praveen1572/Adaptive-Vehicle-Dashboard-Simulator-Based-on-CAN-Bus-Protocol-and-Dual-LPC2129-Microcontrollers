.\ext_intrpt.o: ext_intrpt.c
.\ext_intrpt.o: header.h
.\ext_intrpt.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\ext_intrpt.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
