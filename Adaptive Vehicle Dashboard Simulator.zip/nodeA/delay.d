.\delay.o: delay.c
.\delay.o: header.h
.\delay.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\delay.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
