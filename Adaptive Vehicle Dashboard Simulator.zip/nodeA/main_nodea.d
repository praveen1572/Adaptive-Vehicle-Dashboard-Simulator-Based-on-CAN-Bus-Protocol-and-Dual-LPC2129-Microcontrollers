.\main_nodea.o: main_nodeA.c
.\main_nodea.o: header.h
.\main_nodea.o: C:\Keil-v4\ARM\Inc\Philips\lpc21xx.h
.\main_nodea.o: C:\Keil-v4\ARM\ARMCC\bin\..\include\stdio.h
