can1_intrpt.o: can1_intrpt.c
can1_intrpt.o: header.h
can1_intrpt.o: C:\Keil4\ARM\INC\Philips\lpc21xx.h
can1_intrpt.o: C:\Keil4\ARM\RV31\INC\stdio.h
