.\objects\delay.o: delay.c
.\objects\delay.o: header.h
.\objects\delay.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\delay.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
