.\objects\ext_intrpt.o: ext_intrpt.c
.\objects\ext_intrpt.o: header.h
.\objects\ext_intrpt.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\ext_intrpt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
