.\objects\main_nodeb.o: main_nodeB.c
.\objects\main_nodeb.o: header.h
.\objects\main_nodeb.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\main_nodeb.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
