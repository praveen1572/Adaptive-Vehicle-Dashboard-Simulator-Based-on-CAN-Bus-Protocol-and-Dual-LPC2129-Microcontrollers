.\objects\adc_driver.o: adc_driver.c
.\objects\adc_driver.o: header.h
.\objects\adc_driver.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\adc_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
