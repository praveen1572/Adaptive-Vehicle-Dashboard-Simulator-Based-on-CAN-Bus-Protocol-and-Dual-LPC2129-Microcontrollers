.\objects\main_nodea.o: main_nodeA.c
.\objects\main_nodea.o: header.h
.\objects\main_nodea.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\main_nodea.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
