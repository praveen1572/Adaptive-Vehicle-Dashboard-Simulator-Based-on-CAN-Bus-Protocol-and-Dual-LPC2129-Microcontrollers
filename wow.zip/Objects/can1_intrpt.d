.\objects\can1_intrpt.o: can1_intrpt.c
.\objects\can1_intrpt.o: header.h
.\objects\can1_intrpt.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\objects\can1_intrpt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
