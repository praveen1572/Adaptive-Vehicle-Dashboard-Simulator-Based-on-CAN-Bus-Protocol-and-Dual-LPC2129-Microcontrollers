ext_intrpt.o: ext_intrpt.c
ext_intrpt.o: header.h
ext_intrpt.o: C:\Keil4\ARM\INC\Philips\lpc21xx.h
ext_intrpt.o: C:\Keil4\ARM\RV31\INC\stdio.h
